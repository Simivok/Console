﻿using System;
using System.Collections.Generic;

namespace animek.Model;

public partial class Anime
{
    public int Id { get; set; }

    public string Animenev { get; set; } = null!;

    public int Ev { get; set; }

    public string Mufaj { get; set; } = null!;
}
