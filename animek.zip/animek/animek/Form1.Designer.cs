﻿namespace animek
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            btnSearch = new Button();
            btnYear = new Button();
            dataGridView1 = new DataGridView();
            btnPage = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(89, 35);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(163, 23);
            textBox1.TabIndex = 0;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(89, 64);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(119, 26);
            btnSearch.TabIndex = 1;
            btnSearch.Text = "Keresés";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnYear
            // 
            btnYear.Location = new Point(89, 340);
            btnYear.Name = "btnYear";
            btnYear.Size = new Size(178, 33);
            btnYear.TabIndex = 2;
            btnYear.Text = "Év szerinti rendezes";
            btnYear.UseVisualStyleBackColor = true;
            btnYear.Click += btnYear_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(313, 35);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(475, 338);
            dataGridView1.TabIndex = 3;
            // 
            // btnPage
            // 
            btnPage.Location = new Point(661, 379);
            btnPage.Name = "btnPage";
            btnPage.Size = new Size(127, 34);
            btnPage.TabIndex = 4;
            btnPage.Text = "Új ablak";
            btnPage.UseVisualStyleBackColor = true;
            btnPage.Click += btnPage_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnPage);
            Controls.Add(dataGridView1);
            Controls.Add(btnYear);
            Controls.Add(btnSearch);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button btnSearch;
        private Button btnYear;
        private DataGridView dataGridView1;
        private Button btnPage;
    }
}
